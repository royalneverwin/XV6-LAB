#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include "kernel/param.h"


int
main(int argc, char *argv[]) //argv[1] is command
{
    if(argc < 2){
        fprintf(2, "xargs command is wrong\n");
        exit(1);
    }
    char buf[512];
    char *p = buf;
    char *real_argv[MAXARG] = {0};
    for(int i = 1; i < argc; i++){
        real_argv[i-1] = argv[i];
    }
    while(read(0, p, 1) != 0){
        if(*p != '\n'){ //normal
            p++;
            continue;
        }
        else{ //one command
            *p = 0;
            real_argv[argc - 1] = buf;
            p = buf;
            if(fork() == 0){ //child process
                exec(argv[1], real_argv);
            }
            else{ //father process
                wait(0);
            }
        }
    }
    exit(0);
}