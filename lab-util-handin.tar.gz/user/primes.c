#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int isPrime(int prime, int num){
    if(num % prime == 0){
        return 0;
    }
    else{
        return 1;
    }
}

void CreateChild(int pp[2]){ //pp[2] means connect_pipe with father
    int p[2]; //p[2] means connect_pipe with child
    int prime = 0;
    int num;
    int ifPrime = 0;
    int ifChild = 0;
    if(fork() == 0){ //child process
        close(pp[1]);
        while(1){
            if(read(pp[0], &num, sizeof(num)) == 0) //pipe shut down
                break;
            if(!ifPrime){
                prime = num;
                ifPrime = 1;
                fprintf(1, "prime %d\n", prime);
            }
            else if(isPrime(prime, num)){
                if(!ifChild){
                    pipe(p);
                    CreateChild(p);
                    ifChild = 1;
                }
                write(p[1], &num, sizeof(num));
            }
        }
        close(p[1]);
        close(pp[0]);
        wait(0);
        exit(0);
    }
    else{ //father process
        close(pp[0]);
    }
}


int
main(int argc, char *argv[]) //create child process for every prime, including 2
{
    if(argc != 1){
        fprintf(2, "Command error\n");
        exit(1);
    }
    int p[2];
    pipe(p);
    CreateChild(p);
    for(int i = 2; i <= 35; i++){
        write(p[1], &i ,sizeof(i));
    }
    close(p[1]);
    wait(0);
    exit(0);
}