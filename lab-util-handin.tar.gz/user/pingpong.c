#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int main(int argc, char *argv[]){
    if(argc != 1){
        fprintf(2, "pingpong needs no parameter.\n");
        exit(1);
    }
    
    int p1[2];
    int p2[2];
    char buf = 'A';
    char rebuf;
    int pid;
    pipe(p1); //create pipe1
    pipe(p2); //create pipe2

    if(fork() == 0){ // child process
        close(p1[1]);
        close(p2[0]);
        if(read(p1[0], &rebuf, 1) != 1){ //pay attention to read's wrong
            fprintf(2, "read more or less\n");
            close(p1[0]);
            close(p2[1]);
            exit(1);
        }
        pid = getpid();
        fprintf(1, "%d: received ping\n", pid);
        if(write(p2[1], &buf, 1) != 1){ //pay attention to write's wrong
            fprintf(2, "write more or less\n");
            close(p1[0]);
            close(p2[1]);
            exit(1);
        }
        close(p1[0]);
        close(p2[1]);
        exit(0);
    }

    else{ //father process
        close(p1[0]);
        close(p2[1]);
        if(write(p1[1], &buf, 1) != 1){ //pay attention to write's wrong
            fprintf(2, "write more or less\n");            
            close(p1[1]);
            close(p2[0]);
            exit(1);
        }
        if(read(p2[0], &rebuf, 1) != 1){ //pay attention to read's wrong
            fprintf(2, "read more or less\n");
            close(p1[1]);
            close(p2[0]);
            exit(1);
        }
        pid = getpid();
        fprintf(1, "%d: received pong\n", pid);
        close(p1[1]);
        close(p2[0]);
        wait(0); //wait till child process exit
        exit(0);
    }
}